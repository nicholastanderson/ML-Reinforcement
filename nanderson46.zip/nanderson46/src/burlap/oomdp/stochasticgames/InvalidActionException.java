package burlap.oomdp.stochasticgames;

/**
 * Created by cayle on 5/22/15.
 */
public class InvalidActionException {
}
